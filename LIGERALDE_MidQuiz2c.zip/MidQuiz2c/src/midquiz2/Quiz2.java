package midquiz2;

import javax.management.remote.rmi.RMIConnection;
import javax.management.remote.rmi.RMIServer;
import java.io.IOException;
import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class Quiz2 extends UnicastRemoteObject implements MidQuiz2C {
    String[] ids = TimeZone.getAvailableIDs(-8 * 60 * 60 * 100);
    SimpleTimeZone pdt = new SimpleTimeZone(-8 * 60 * 60 * 100, ids[0]);
    GregorianCalendar calendar = new GregorianCalendar(pdt);

    protected Quiz2() throws RemoteException {
    }

    @Override
    public String dotw(int m, int d, int y) throws RemoteException {
        if (m==calendar.get(calendar.MONTH) || d==calendar.get(calendar.DAY_OF_MONTH) || y==calendar.get(calendar.YEAR)) {
            return String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
        }
        return null;
    }

    @Override
    public int age(Calendar birthDate) throws RemoteException {
        if (birthDate.isWeekDateSupported()){
            int age = 2023-birthDate.get(calendar.YEAR);
            return age;
        }
        return 0;
    }

    @Override
    public boolean isLeapYear(int year) throws RemoteException {
        return false;
    }

    public static void main(String[] args) throws RemoteException {
        try {
            MidQuiz2C stub = new Registry(MidQuiz2C);
            Registry regbind = LocateRegistry.createRegistry(1099);
            System.out.println("RMI BOUND");
        } catch (NoSuchObjectException e) {
            throw new RuntimeException(e);
        }
    }

}
