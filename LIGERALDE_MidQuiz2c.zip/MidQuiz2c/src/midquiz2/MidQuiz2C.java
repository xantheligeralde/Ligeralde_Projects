package midquiz2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Calendar;

public interface MidQuiz2C extends Remote {
    /* dotw: method that returns the day of the week (monday, tuesday, etc.) of the given date (parameter)
       		m = month, d = day, y = year
       if the date is not valid (ex. february 31, 2010), return the string "invalid"
     */
    public String dotw(int m, int d, int y) throws RemoteException;

    /* age: method that returns the age in years given a date parameter
       note: if the parameter is beyond the current date, the return value is zero (0).
       examples:
           if the parameter is (january 30, 2000), return value is 12.
           if the parameter is (december 21, 2023), return value is 00.
     */
    public int age(Calendar birthDate) throws RemoteException;

    /* leapYear: determines if the year provided (parameter) is a leap year or not
       note:
          a leap year can qualify as a leap year based on the following:
             1. non-century year -> exactly divisible by 4
             2. century year -> exactly divisible by 400
                * a century year ends in 00, ex. 1900, 1600, 1800, etc.
       example: 1400 should be a non-leap year
     */

    public boolean isLeapYear(int year) throws RemoteException;
}
// Note:  Use port 1099 in setting up your RMI registry
/* To have your work checked:
    1. VERY IMPORTANT: Disable the VirtualBox Network Adapter!!!
    2. Run your server program.
    3. To run the program checker, open the command prompt.
        * issue the command: telnet IP_Address 4321
            - The program checker's IP_Address will be written by the
              faculty-in-charge on the whiteboard.
            - If the telnet command does not work, enable it via
              the control panel of Windows.
    4. You may run the checker multiple times but within the allowable
       time as specified by the faculty-in-charge.
    5. If you are finished with your work, have your program submitted in the
       submission box provided by the faculty-in-charge by archiving (zipping)
       your project and uploading the generated file.
    6. After submitting your work, delete all your files on the terminal that
       you are using.  You may need to empty the recycle bin of Windows after.
 */