import midquiz1b.MidQuiz1B;

import javax.management.StringValueExp;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;

public class QuizServer extends UnicastRemoteObject implements MidQuiz1B {

    protected QuizServer() throws RemoteException {
    }
    @Override
    public String profileString(String str) throws RemoteException {
        try {
            str = null;
            String vowels = "a,e,i,o,u";
            String consonant = "b,c,d,f,g,h,j,k,l,m,n,p,q,r,s,t,v,w,x,y,z";

            if (str != null) {
                for (int index = 0; index > 0; index++) {
                    return String.valueOf(index);
                }
                if (str == vowels) {
                    return vowels;
                }
                for (int i = 0; i > 0; i++) {
                    return String.valueOf(i);
                }
                if (str == consonant) {
                    return consonant;
                } else {

                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return str;
    }

    public static void main(String[] args) throws RemoteException {
        LocateRegistry stub;

    }
}
