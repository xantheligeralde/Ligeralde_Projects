package midquiz1b;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MidQuiz1B extends Remote {
    /*  profileString is a method that will return the following in one line:
        number of letters (alphabets) in a string + space +
        all vowels in order of their appearance + space + number of vowels +
        space + all consonants in order of their appearance + space +
        number of consonants

        e.g. profileString("sa1nt & louis") will return
        "9 aoui 4 sntls 5"
        Notice that all non-letters will be ignored in teh computation of vowels
        and consonants but included in the computation of the string size
     */
    String profileString(String str) throws RemoteException;
}
// Note:  Use port 1099 in setting up your RMI registry
/* To have your work checked:
    1. VERY IMPORTANT: Disable the VirtualBox Network Adapter!!!
    2. Run your server program.
    3. To run the program checker, open the command prompt.
        a. check the IP address of the terminal you are using.
        b. issue the command: telnet IP_Address 4321
            - The program checker's IP_Address will be written by the
              faculty-in-charge on the whiteboard.
            - If the telnet command does not work, enable it via
              the control panel of Windows.
        c. if you made an error in encoding any of your answers from
           the questions asked, CLOSE THE WINDOW AND START ALL OVER AGAIN.
    4. You may run the checker multiple times but within the allowable
       time as specified by the faculty-in-charge.
    5. If you are finished with your work, have your program submitted in the
       submission box provided by the faculty-in-charge by archiving (zipping)
       your project and uploading the generated file.
 */
