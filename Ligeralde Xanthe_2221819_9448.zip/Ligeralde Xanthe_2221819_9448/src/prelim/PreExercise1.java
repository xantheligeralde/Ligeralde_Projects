package prelim;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class PreExercise1 {
    public static void main(String[] args){

            char choice;

            do {
                Scanner kybr = new Scanner(System.in);
                System.out.print("Type IP address/Hostname: ");
                String host = kybr.nextLine();

                try {
                    InetAddress[] ipAdd = InetAddress.getAllByName(host);

                    System.out.println("Number of Hosts/IP: " + ipAdd.length);
                    System.out.println("Host name IP Address: ");

                    for (int i=0; i<ipAdd.length; i++) {
                        System.out.println(ipAdd[i]);
                    }

                } catch (UnknownHostException e) {
                    System.out.println("Host " + host + " does not exist!");

                }
                System.out.print("Do you want to search another [y/n]? ");
                choice = kybr.next().charAt(0);

            } while (choice== 'y');
    }
}