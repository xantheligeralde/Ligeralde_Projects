package pexer3;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerExer3 {
    public static void main(String[] args) {
        int port = 2080;
        try (
                ServerSocket server = new ServerSocket(port);
                Socket client = server.accept();
                PrintWriter streamWtr = new PrintWriter(client.getOutputStream(), true)
        ) {
            File path = new File("res/exer3.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(path);

            document.getDocumentElement().normalize();
            NodeList tagName = document.getElementsByTagName("citizen");
            display(tagName, streamWtr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void display(NodeList list, PrintWriter streamWtr) {
        String CYAN = "\u001B[36m";
        String PURPLE = "\u001B[35m";
        for (int i = 0; i <= list.getLength(); i++) {
            Node node = list.item(i);
            Element element = (Element) node;

            try {
                String name = element.getElementsByTagName("name").item(0).getTextContent();
                int age = Integer.parseInt(element.getElementsByTagName("age").item(0).getTextContent());
                if (age < 18) {
                    streamWtr.println((CYAN + name) + " ,you're still too young to vote!");
                } else {
                    streamWtr.println((PURPLE + name) + " ,you may exercise your right to vote");
                }
            } catch (NullPointerException e) {
                System.out.println("Bye!!");
            }
        }
    }
}