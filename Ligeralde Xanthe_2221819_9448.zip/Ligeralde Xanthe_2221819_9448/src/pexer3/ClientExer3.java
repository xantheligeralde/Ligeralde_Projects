package pexer3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientExer3 {
    public static void main(String[] args) {

        int port = 2080;

        try(
                Socket socket = new Socket("127.0.0.1", port);
                BufferedReader streamRdrd = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ){
            String results = streamRdrd.readLine();
            while (results != null){
                System.out.println(results);
                results = streamRdrd.readLine();
            }
            System.out.println("Bye!");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}