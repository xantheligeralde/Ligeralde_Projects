package pexer2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerExer2 {
    public static void main(String[] args) {
        int port = 2070;
        try (ServerSocket serverSocket = new ServerSocket(port)){
                Socket clientSocket = serverSocket.accept();
                Client client = new Client(clientSocket);
                client.run();
            } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}