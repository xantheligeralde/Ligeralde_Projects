package pexer2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client implements Runnable {
    private Socket socket;

    public Client(Socket socket) throws IOException {
        this.socket = socket;
    }

    @Override
    public void run() {
        while (true) {
            try {
                BufferedReader streamRdr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter streamWtr = new PrintWriter(socket.getOutputStream(), true);
                while (true) {
                    int age;
                    while (true) {
                        streamWtr.println("What is your name? ");
                        String name = streamRdr.readLine();
                        streamWtr.println("What is your age? ");
                        try {
                            age = Integer.parseInt(streamRdr.readLine());
                            if (age == 0) {
                                throw new NumberFormatException();
                            } else if (age >= 18) {
                                streamWtr.println(name + ", you may exercise your right to vote!");
                                streamWtr.println("==============================================");
                            } else {
                                streamWtr.println(name + ", you are still too young to vote!");
                                streamWtr.println("==============================================");
                            }
                        } catch (NumberFormatException e) {
                            streamWtr.println("Please enter a valid age!");
                            streamWtr.println("==================================================");
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}