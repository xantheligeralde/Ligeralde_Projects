package pregroup06;

public class MixedFraction {
}
