package pregroup06;public class Fraction {
}
