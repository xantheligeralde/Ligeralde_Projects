package MidtermGroup6Project.prog2.midgroup06;

/**
 * Name of Student/Programmer:
 * DE JESUS, JOSE MIGUEL
 * SOLBITA, OLCEN
 * VIERNES, JOSHUA
 * LIGERALDE, XANTHE
 *
 * Date: March 17, 2022
 *
 * Summary of exception handling added to the MixedFraction project:
 *
 * 1. For the read method under the Fraction class, Number Exception was utilized to catch the failed attempt upon conversion. The prompt String variable was used to show a prompt message and notify the user about the error.
 *
 *
 *         try
 *         {
 *             //no divider as to no denominator was specified 'undefined variable'
 *             if (end == -1)
 *             {
 *                 numerator = Integer.parseInt (frac);
 *                 denominator = 1;
 *             }
 *             else //there is a divider for the fraction
 *             {
 *                 numerator = Integer.parseInt (frac.substring (0, end)); //numerator comes before the divider
 *                 denominator = Integer.parseInt (frac.substring (end + 1)); //denominator comes after the divider
 *                 if (denominator == 0)
 *                     prompt = "The fraction cannot be determined please try again.";
 *             }
 *             if (numerator < 0 && denominator < 0 || (numerator > 0 && denominator < 0)) //if denominator has a negative value, or both are negative
 *             {
 *                 numerator *= -1;
 *                 denominator *= -1;
 *             }
 *         }
 *         catch (NumberFormatException e)  //Catches failed attempt
 *         {
 *             prompt = ("The fraction cannot be determined please try again."); //stops from crashing and changes the prompt
 *         }
 *
 *
 *
 * 2. As for the main method under the Fraction tester class, Arithmetic Exception is utilized when the denominator equals zero.
 *
 *  This code is from case 1 under switch(choice), case 1 is somehow similar to case 2, it just differs from their inputs (Fraction vs Mixed Fraction)
 *
 *    try {
 *                     System.out.print("Enter the numerator of the first fraction: ");
 *                     numOne = Integer.parseInt(kb.nextLine());
 *                     System.out.print("Enter the denominator of the first fraction: ");
 *                     denOne = Integer.parseInt(kb.nextLine());
 *
 *                     System.out.print("Enter the numerator of the second fraction: ");
 *                     numTwo = Integer.parseInt(kb.nextLine());
 *                     System.out.print("Enter the denominator of the second fraction: ");
 *                     denTwo = Integer.parseInt(kb.nextLine());
 *
 *                     System.out.println("----------------------------------------------------");
 *                     System.out.println("                      RESULTS                       ");
 *                     System.out.println();
 *
 *                     System.out.println("GIVEN (NOT SIMPLIFIED) ");
 *                     System.out.println("First Fraction : " + numOne + "/ " + denOne);
 *                     System.out.println("Second Fraction : " + numTwo + "/ " + denTwo);
 *                     System.out.println();
 *
 *                     System.out.println("GIVEN (SIMPLIFIED) ");
 *                     fractionOne = new Fraction(numOne,denOne);
 *                     System.out.print("First Fraction: ");
 *                     System.out.println(fractionOne);
 *
 *                     fractionTwo =new Fraction(numTwo,denTwo);
 *                     System.out.print("Second Fraction: ");
 *                     System.out.println(fractionTwo);
 *
 *                     System.out.println("----------------------------------------------------");
 *
 *                     System.out.println("ADDITION: ");
 *                     answer = fractionOne.add(fractionTwo);
 *                     System.out.println( " "+ fractionOne + " and " + fractionTwo + " is : " + answer);
 *                     System.out.println();
 *
 *                     System.out.println("SUBTRACTION: ");
 *                     answer = fractionOne.subtract(fractionTwo);
 *                     System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + answer);
 *                     System.out.println();
 *
 *                     System.out.println("MULTIPLICATION: ");
 *                     answer = fractionOne.multiply(fractionTwo);
 *                     System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + answer);
 *                     System.out.println();
 *
 *                     System.out.println("DIVISION: ");
 *                     answer = fractionOne.divide(fractionTwo);
 *                     System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + (answer));
 *                     System.out.println();
 *
 *                 } catch (ArithmeticException e){
 *                     System.out.println("Sorry, the denominator cannot be zero.");
 *                     System.exit(0);
 *                 }
 *
 */

import java.util.Scanner;

/**
 * This FractionTester class is used to generate the methods
 */

public class FractionTester {

    public static void main(String[] args) {

        /*
         * A scanner is utilized to get user inputs
         */
        Scanner kb = new Scanner(System.in);

        Fraction f1 = new Fraction();

        // declaration of variable's data types
        int choice;
        int choice2;
        Fraction fractionOne;
        Fraction fractionTwo;
        Fraction answer;
        MixedFraction mixed1;
        MixedFraction mixed2;
        MixedFraction answer2;

        // initialization of variables
        int numOne;
        int denOne;
        int numTwo;
        int denTwo;

        displayIntroduction();
        kb.nextLine();
        System.out.println();

        displayMainMenu();
        do {
            System.out.print("Enter you choice: ");
            choice = Integer.parseInt(kb.nextLine());
            if (choice > 3 || choice < 1)
                System.out.println("Invalid choice! Valid options 1-3 only. ");
        } while (choice > 3 || choice < 1);

        switch (choice) {

            /**
             * This is for Common Fractions
             */
            case 1:

                try {
                    System.out.print("Enter the numerator of the first fraction: ");
                    numOne = Integer.parseInt(kb.nextLine());
                    System.out.print("Enter the denominator of the first fraction: ");
                    denOne = Integer.parseInt(kb.nextLine());

                    System.out.print("Enter the numerator of the second fraction: ");
                    numTwo = Integer.parseInt(kb.nextLine());
                    System.out.print("Enter the denominator of the second fraction: ");
                    denTwo = Integer.parseInt(kb.nextLine());

                    fractionOne = new Fraction(numOne, denOne);
                    System.out.print("First Fraction: ");
                    System.out.println(fractionOne);

                    fractionTwo = new Fraction(numTwo, denTwo);
                    System.out.print("Second Fraction: ");
                    System.out.println(fractionTwo);
                    System.out.println();

                    System.out.println("----------------------------------------------------");
                    System.out.println("                      OPERATIONS                    ");
                    System.out.println("                What do you want to do?             ");
                    System.out.println("----------------------------------------------------");

                    System.out.println("1. Add Fraction 1 and Fraction 2");
                    System.out.println("2. Subtract Fraction 1 and Fraction 2");
                    System.out.println("3. Multiply Fraction 1 and Fraction 2");
                    System.out.println("4. Divide Fraction 1 and Fraction 2");
                    System.out.println("5. Exit");

                    // input validation
                    do {
                        System.out.print("Enter your choice: ");
                        choice2 = Integer.parseInt(kb.nextLine());
                        if (choice2 > 5 || choice2 < 1)
                            System.out.println("Sorry, invalid choice. Try again! ");
                    } while (choice2 > 5 || choice2 < 1);

                    switch (choice2) {

                        // addition
                        case 1 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + numOne + "/" + denOne);
                            System.out.println("Second Fraction :  " + numTwo + "/" + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("ADDITION: ");
                            answer = fractionOne.add(fractionTwo);
                            System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + answer);
                            System.out.println();
                        }

                        // subtraction
                        case 2 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + numOne + "/" + denOne);
                            System.out.println("Second Fraction :  " + numTwo + "/" + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("SUBTRACTION: ");
                            answer = fractionOne.subtract(fractionTwo);
                            System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + answer);
                            System.out.println();
                        }

                        // multiplication
                        case 3 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + numOne + "/" + denOne);
                            System.out.println("Second Fraction :  " + numTwo + "/" + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("MULTIPLICATION: ");
                            answer = fractionOne.multiply(fractionTwo);
                            System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + answer);
                            System.out.println();
                        }

                        // division
                        case 4 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + numOne + "/" + denOne);
                            System.out.println("Second Fraction :  " + numTwo + "/" + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("DIVISION: ");
                            answer = fractionOne.divide(fractionTwo);
                            System.out.println(" " + fractionOne + " and " + fractionTwo + " is : " + (answer));
                            System.out.println();
                        }

                        // exits the program
                        case 5 -> {
                            System.out.println("\n");
                            System.out.println("This program will now close.");
                            System.out.println("Enjoy the rest of your day.");
                            System.exit(0);
                        }
                    }

                } catch (ArithmeticException e) {
                    System.out.println("Sorry, the denominator cannot be zero.");
                    System.exit(0);
                }
                break;

            /**
             * This is for Mixed Fractions
             */
            case 2:
                try {
                    System.out.print("Enter the whole number of the first fraction: ");
                    int whole1 = Integer.parseInt(kb.nextLine());

                    System.out.print("Enter the numerator of the first fraction: ");
                    numOne = Integer.parseInt(kb.nextLine());
                    System.out.print("Enter the denominator of the first fraction: ");
                    denOne = Integer.parseInt(kb.nextLine());

                    System.out.print("Enter the whole number of the second fraction: ");
                    int whole2 = Integer.parseInt(kb.nextLine());

                    System.out.print("Enter the numerator of the second fraction: ");
                    numTwo = Integer.parseInt(kb.nextLine());
                    System.out.print("Enter the denominator of the second fraction: ");
                    denTwo = Integer.parseInt(kb.nextLine());

                    mixed1 = new MixedFraction(whole1, numOne, denOne);
                    System.out.print("First Mixed Fraction: ");
                    System.out.println(mixed1);

                    mixed2 = new MixedFraction(whole2, numTwo, denTwo);
                    System.out.print("Second Mixed Fraction: ");
                    System.out.println(mixed2);


                    System.out.println("----------------------------------------------------");
                    System.out.println("                      OPERATIONS                    ");
                    System.out.println("                What do you want to do?             ");
                    System.out.println("----------------------------------------------------");

                    System.out.println();
                    System.out.println("1. Add Fraction 1 and Fraction 2");
                    System.out.println("2. Subtract Fraction 1 and Fraction 2");
                    System.out.println("3. Multiply Fraction 1 and Fraction 2");
                    System.out.println("4. Divide Fraction 1 and Fraction 2");
                    System.out.println("5. Exit");

                    // data validation
                    do {
                        System.out.print("Input the number corresponding to your choice: ");
                        choice2 = Integer.parseInt(kb.nextLine());
                        if (choice2 > 5 || choice2 < 1)
                            System.out.println("Sorry, invalid choice. Try again! ");
                    } while (choice2 > 5 || choice2 < 1);

                    switch (choice2) {
                        // addition
                        case 1 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + whole1 + " " + numOne + "/ " + denOne);
                            System.out.println("Second Fraction : " + whole2 + " " + numTwo + "/ " + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("ADDITION: ");
                            answer2 = mixed1.add(mixed2);
                            System.out.println(" " + mixed1 + " and " + mixed2 + " is : " + answer2);
                            System.out.println();
                        }
                        // subtraction
                        case 2 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + whole1 + " " + numOne + "/ " + denOne);
                            System.out.println("Second Fraction : " + whole2 + " " + numTwo + "/ " + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("SUBTRACTION: ");
                            answer2 = mixed1.subtract(mixed2);
                            System.out.println(" " + mixed1 + " and " + mixed2 + " is : " + answer2);
                            System.out.println();
                        }
                        // multiplication
                        case 3 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + whole1 + " " + numOne + "/ " + denOne);
                            System.out.println("Second Fraction : " + whole2 + " " + numTwo + "/ " + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("MULTIPLICATION: ");
                            answer2 = mixed1.multiply(mixed2);
                            System.out.println(" " + mixed1 + " and " + mixed2 + " is : " + answer2);
                            System.out.println();
                        }
                        // division
                        case 4 -> {
                            System.out.println("----------------------------------------------------");
                            System.out.println("                      RESULTS                       ");
                            System.out.println();
                            System.out.println("GIVEN");
                            System.out.println("First Fraction : " + whole1 + " " + numOne + "/ " + denOne);
                            System.out.println("Second Fraction : " + whole2 + " " + numTwo + "/ " + denTwo);
                            System.out.println();
                            System.out.println("----------------------------------------------------");
                            System.out.println("DIVISION: ");
                            answer2 = mixed1.divide(mixed2);
                            System.out.println(" " + mixed1 + " and " + mixed2 + " is : " + answer2);
                            System.out.println();
                        }
                    } // end of switch

                } catch (ArithmeticException e) {
                    System.out.println("Sorry, the denominator cannot be zero.");
                    System.exit(0);
                }
                break;
            case 3:
                System.out.println("\n");
                System.out.println("This program will now close.");
                System.out.println("Enjoy the rest of your day.");
                System.exit(0);
        }
    }
    // introduction to the program
    public static void displayIntroduction() {
        System.out.println("\n");
        System.out.println("Fraction Tester Program");
        System.out.println("---------------------------------------------");
        System.out.println("""
                This program facilitates addition, subtraction,
                multiplication and division of mixed multiplication
                and division of mixed of the inputs/outputs may
                involve fractions, mixed fractions or combinations.      \s""");
        System.out.println("\n");
        System.out.print("Press ENTER key to create two Fractions... ");
    } //end displayIntroduction method

    public static void displayMainMenu () {
        // main menu
        System.out.println("Main menu: ");
        System.out.println("1. Common Fractions ");
        System.out.println("2. Mixed Fractions ");
        System.out.println("3. Exit");
        System.out.println();
    } // end displayMainMenu method

    public static int inputChoice(int min, int max) {
        Scanner kbd = new Scanner(System.in);
        int choice;
        do {
            System.out.print("Input the number corresponding to your choice: ");
            choice = kbd.nextInt();
            if (choice < min || choice > max)
                System.out.println("Invalid choice. Please ensure that you enter a number from " + min + " to " + max + ".");
        } while (choice < min || choice > max);
        return (choice);
    } //end of enterChoice() method
}



