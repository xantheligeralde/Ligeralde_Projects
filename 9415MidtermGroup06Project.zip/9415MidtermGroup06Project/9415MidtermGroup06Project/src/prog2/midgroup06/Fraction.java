package prog2.midgroup06;

public class Fraction
{
    /**
     * The data variables of the fraction class are set to protected and are integers.
     **/
    protected int numerator, denominator, gcf, mult1, mult2, newDen, newNum1, newNum2;

    /**
     *  This is the default constructor for the fraction class
     */
    public Fraction ()
    {
        numerator = 0;
        denominator = 1;
    }

    /** This method shows the copy constructor of fraction class
     *
     * @param F
     */
    public Fraction (Fraction F)
    {
        numerator = F.numerator;
        denominator = F.denominator;
    }

    /** This is the alternate constructor of the fraction class
     *
     * @param num
     * @param den
     */
    public Fraction (int num, int den)
    {
        numerator = num;
        denominator = den;
    }

    /**
     *  The getDenom method is the getter method for the denominator
     *
     * @param A
     */
    public int getDenom (Fraction A)
    {
        return A.denominator;
    }

    /**
     *  The readMethod utilize a scanner from the keyboard
     *
     * @param frac
     */
    public void read (String frac)
    {
        int end = frac.indexOf ("/"); //returns index where the divider is
        String prompt;
        try
        {
            //no divider as to no denominator was specified 'undefined variable'
            if (end == -1)
            {
                numerator = Integer.parseInt (frac);
                denominator = 1;
            }
            else //there is a divider for the fraction
            {
                numerator = Integer.parseInt (frac.substring (0, end)); //numerator comes before the divider
                denominator = Integer.parseInt (frac.substring (end + 1)); //denominator comes after the divider
                if (denominator == 0)
                    prompt = "The fraction cannot be determined please try again.";
            }
            if (numerator < 0 && denominator < 0 || (numerator > 0 && denominator < 0)) //if denominator has a negative value, or both are negative
            {
                numerator *= -1;
                denominator *= -1;
            }
        }
        catch (NumberFormatException e)  //Catches failed attempt
        {
            prompt = ("The fraction cannot be determined please try again."); //stops from crashing and changes the prompt
        }
    }

    /**
     * The toString method overrides the Object toString for printing
     *
     */
    public String toString ()
    {
        if (numerator == 0 && denominator != 0) //a number divided by 0 becomes automatically 0
            return (0 + ""); //display zero
        else if (denominator == 1)
            return (numerator + ""); //a number divided by 1 becomes the number itself
        else
            return (numerator + "/" + denominator); //display
    }

    /**
     * The gcfRec method is used to determine the greatest common factor
     *
     * @param a
     * @param b
     **/
    public int gcfRec (int a, int b)
    {
        if (a == b) //if the numbers are equal, then the GCF is the number
            return a;
        else if (a < b) //switches the larger number to the first spot, and sets up for the next step
            return (gcfRec (b, a));
        else //when larger number is in first spot (a > b)
            return (gcfRec (b, a - b)); //decreases the numbers by the differences between till the numbers are the same
    }


    /**
     *  The reduce method reduces the fractions to the lowest terms, carries out the gcfRec
     **/
    public void reduce ()
    {
        if (numerator != 0)
        {
            gcf = gcfRec (Math.abs (numerator), denominator); //find the greatest common factor
            numerator = numerator / gcf; //change the stored numerator to the reduced one
            denominator = denominator / gcf; //change the stored denominator to the reduced one
        }
    }

    /**
     * The add method is to add the fraction's one and two.
     *
     * @param B
     **/
    public Fraction add (Fraction B)  //returns a new fraction based on the addition of a fraction and another fraction
    {
        gcf = gcfRec (denominator, B.denominator); //gets the gcf of the denominators of the fractions
        mult1 = B.denominator / gcf; //first multiplier
        newDen = denominator * mult1; //shared, equal denominators
        newNum1 = numerator * mult1;  //new numerator is found for first fraction
        mult2 = denominator / gcf; //other multiplier
        newNum2 = B.numerator * mult2; //new numerator is found for second fraction
        return new Fraction (newNum1 + newNum2, newDen); //return the whole new fraction
    }

    /**
     * The subtract method is to subtract the fraction's one and two.
     * @param B
     */
    public Fraction subtract (Fraction B)
    {
        if (numerator != 0 && B.numerator != 0)
        {
            gcf = gcfRec (denominator, B.denominator); //gets the gcf of the denominators of the fractions
            mult1 = B.denominator / gcf; //first multiplier
            newDen = denominator * mult1; //shared, equal denominators
            newNum1 = numerator * mult1;  //new numerator is found for first fraction
            mult2 = denominator / gcf; //other multiplier
            newNum2 = B.numerator * mult2; //new numerator is found for second fraction
            return new Fraction (newNum1 - newNum2, newDen); //return the whole new fraction
        }
        else
            return new Fraction (B.numerator * -1, B.denominator); //negative of the non-zero fraction
    }

    /**
     * The multiply method is to multiply the fraction's one and two.
     * @param B
     */
    public Fraction multiply (Fraction B)
    {
        return new Fraction (numerator * B.numerator, denominator * B.denominator);
    }

    /**
     * The divide method is to divide the fraction's one and two.
     * @param B
     */

    public Fraction divide (Fraction B)
    {
        return new Fraction (numerator * B.denominator, denominator * B.numerator);
    }// end of method
}// end of class


