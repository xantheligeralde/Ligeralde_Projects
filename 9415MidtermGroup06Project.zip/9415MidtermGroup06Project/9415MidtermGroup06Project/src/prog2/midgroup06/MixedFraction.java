package prog2.midgroup06;

public class MixedFraction {
}
